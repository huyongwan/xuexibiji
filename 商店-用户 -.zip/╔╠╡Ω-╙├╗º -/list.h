#include<stdio.h>
#include<stdlib.h>
#include<assert.h>
#include<string.h>

typedef int SU;

typedef struct order
{
	char name[200];
	float price;
	int num;
	char status[200];
	char address[200];	
	
}OR[200];
typedef struct acc
{
	char accoumt[200];//�˺�
	char pass[200];//���� 
	char name[200];//�û��� 
	char find[200];//�һ��������� 		
	OR order; //����
	float money;//�ʽ� 
	OR foot;//�㼣 
 }MU; 

typedef struct mima1
{
	char accoumt[200];//�˺�
	char pass[200];//���� 
	char name[200];//�û��� 
	char find[200];//�һ��������� 
	OR book;//����	
	float money;
	
}MI;

typedef struct goods
{
	int  num;//��Ʒ���
	char name[200];//��Ʒ����
	float price;//��Ʒ�۸�
	int numb;//��Ʒ���� 
	
	
	
 }Goods; 


typedef struct list
{
	Goods data;
	struct list*next;
	struct list*prev;
	
}SL;
SL* listInit(SL*px);
void listinsert(SL*pos,SU X);
void listprint(SL*px); 
void listpush(SL*px);
void popback(SL*px);
void listdestory(SL**px);
SL*listfind(SL*px,char* X);
SL*listmalloc();
void listearse(SL*pos);
void listmenu(); 
void listxiugai(SL*px);
void listchuangjian(MI**px);
void listdenglu(MI**px);
void listdenglu1(MU**px);
void listfindpass(MI**px);
void Preserve (SL* head);
void listread (SL*px);
 void listread1 (MI**px);
 void listread2 (MU**px);
void listchuangjian1(MU**px);
void listpurchar(SL*px,MU*ps,MI*pa);
void listorder(MU*ps); 
void listmenu1(); 
void listfoot(MU*ps); 
void listlufoot(SL*px,MU*ps);
void listbook(MI*pa); 
void listInformation(MI*px);
void listInformation1(MU*px);
void listZeng(SL*px);
void listrecharge(MU*px);
void listBook(SL*px,MU*ps,MI*pa,char*t);
 void Preserve1 (MI*px);
 void Preserve2 (MU*px);
