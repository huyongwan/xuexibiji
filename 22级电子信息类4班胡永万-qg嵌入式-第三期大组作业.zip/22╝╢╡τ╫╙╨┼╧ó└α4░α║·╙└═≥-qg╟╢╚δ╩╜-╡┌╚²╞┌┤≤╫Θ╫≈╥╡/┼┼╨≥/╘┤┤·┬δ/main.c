#include <stdio.h>
#include <stdlib.h>
#include"list.h"
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
//	int pn;
	int i;
	int mn;
	int n;
//	printf("���������鳤��:");
//	scanf("%d", &n);
//
//	int *a = (int*)malloc(n*sizeof(int));
//
//	for ( i = 0; i < n; i++)
//	{
//	printf("��Ϊ�����%dԪ�ظ�ֵ:",i+1);
//	scanf("%d", &a[i]);
//	printf("%d\n",a[i]);
//	}
printf("ʦ�֣�scanf�������������⣬�ȶ��������飬������������"); 
	int a[5]={5,4,3,2,1};
//	scanf("%d",&pn);
	//int v;
	n=5;
	int len=sizeof(a)/sizeof(int);
//	for(i=0;i<pn;i++)
//	{
//	scanf("%d",&v);
//    a[i]=v;
//	}
//	
	for(i=0;i<n;i++)
	{
		printf("%d\n",a[i]);
	}
	while(1){
		 mume();
	printf("����������ѡ��Ĺ��ܣ�");
	scanf("%d",&mn); 
	switch(mn){
		case 1:
		listmaopao(&a,len);
		for(i=0;i<n;i++)
	{
		printf("%d",a[i]);
	}
	printf("\n");
		break;
		case 2:
			listkuaisu(a,len);
		for(i=0;i<n;i++)
	{
		printf("%d",a[i]);
	}
		printf("\n");
		break;
		case 3:
			listcharu(a,len);
		for(i=0;i<n;i++)
	{
		printf("%d",a[i]);
	}
		printf("\n");
		break;
		case 4:
			listxier(a,len);
		for(i=0;i<n;i++)
	{
		printf("%d",a[i]);
	}
		printf("\n");
		break;
		case 5:
			listxuanze(a,len);
		for(i=0;i<n;i++)
	{
		printf("%d",a[i]);
	}
		printf("\n");
		break;
		case 6:
			listjishu2(a,len);
		for(i=0;i<n;i++)
	{
		printf("%d",a[i]);
	}
		printf("\n");
		break;
		case 7:
			listjishu(a,len);
		for(i=0;i<n;i++)
	{
		printf("%d",a[i]);
	}
		printf("\n");
		break;
		case 8:
		listdui1(a,len);
		for(i=0;i<n;i++)
	{
		printf("%d",a[i]);
	}
		printf("\n");
		break; 
	
		case 9:
			listtong(a,len);
			for(i=0;i<n;i++)
		{
			printf("%d",a[i]);
		}
			printf("\n");
			break; 
		case 10:
		return;	
}
	
}
	return 0;
	
}

