#include<stdio.h>
#include<stdlib.h>


void listmaopao(int **a,unsigned int len);
void listkuaisu(int *a,unsigned int len); 
void listcharu(int *a,unsigned int len);
void listxier1(int *a, int len, int p,int s);
void listxier(int *a,unsigned int len);
void listxuanze(int *a,unsigned int len);
int max(int *a,unsigned int len);
int max1(int *a,unsigned int len);
void listjishu(int *a,unsigned int len);
void listjishu1(int *a,unsigned int len,unsigned int e);
void listdui(int *a,int s,int e);
void listdui1(int *a, int len);
void listjishu2(int *a,unsigned int len);
void listtong(int *a,unsigned int len);
void listtong1(int *a,unsigned int len);
void mume(); 
