#include<stdio.h>
#include"list.h"
#include"string.h"


//ð������ 
void listmaopao(int *a,unsigned int len)
{                     
	if (len<2) 
	return; 
	 int i;    
	 int j;     
	 int t;  
	 int s; 
	
	    for (i=len-1;i>0;i--)  
	     {printf("i=%d\n",i);    
		 s=0; 
	    for (j=0;j<i;j++)
		{   
			if (a[j]>a[j+1]) 
			{      t=a[j+1];    
			    a[j+1]=a[j];     
				   a[j]=t;    
				       s=1; 
			}  
		}  
		     if (s==0) 
			 return; 
		}
 } 
 
 //�������� 
 void listkuaisu(int *a,unsigned int len) 
{  
	if (len<2)
  return;  
  int t=a[0];  
  int l=0;      
  int r=len-1; 
  int m=2;   
  while (l<r)
{ 
	if (m==2)
 	{    
		 if (a[r]>=t) 
		 { 
		  r--;
		  continue; 
		  }            
	
		a[l]=a[r];    
		l++;     
		m=1; 
		continue;
		
	 }   
	if (m==1) 
	{     
		if(a[l]<=t)
		{ 
			l++; 
			continue;
		 }     
		
			a[r]=a[l];     
			r--;   
			m=2;  
			continue; 
	} 
} 
	a[l]=t; 
	listkuaisu(a,l);            
	listkuaisu(a+l+1,len-l-1); 
} 
//�������� 
void listcharu(int *a,unsigned int len)
{ 
	 if (len<2) 
	 return; 
	 int tmp;  
	 int i;    
	 int j;  
	for (i=1;i<len;i++)  
	{   
	  tmp=a[i];   
	  
	    for (j=i-1;j>=0;j--)   
		 {     
		  if (a[j]<=tmp)
		   break;      
			a[j+1]=a[j];
		}   
		  a[j+1]=tmp;
	}
}

//ϣ������ 
void listxier1(int *a, int len, int p,int s)
{  
	int t;   
    int i;   
    int j;   
    for (i=p+s;i<len;i=i+s)  
    {    
		t=a[i];   
		for (j=i-s;j>=0;j=j-s)   
		{ 
		  if (a[j]<=t)
		   break;       
		  a[j+s]=a[j];  
		}    
			a[j+s]=t; 
	}
}

void listxier(int *a,unsigned int len)
{  
	int i,s;    
	for (s=len/2;s>0;s=s/2) 
 	{    
	  	for (i=0;i<s;i++)   
	   {  
	      listxier1(a,len,i,s);  
	    } 
	}
}
void swap(int*x,int*y)
{
	int t=*x;
	*x=*y;
	*y=t;
	
	
 } 
//ѡ������ 

void listxuanze(int *a,unsigned int len)
{  
   if (len<2)
   return;  
   int i;      
   int j;    
   int m;
 
   for (i=0;i<len-1;i++) 
    {   
		 m=i;   
		 for (j=i+1;j<len;j++) 
		{     
		   if (a[j]<a[m]) 
		    m=j; 
		}   
		   
		if (m!=i) 
		swap(&a[i],&a[m]); 
	}
}

//�������� 

int max(int *a,unsigned int len)
{ 
   int i=0; 
   int max=0;
   for (i=0;i<len;i++) 
   if (max<a[i])
    max=a[i]; 
	 return max;
}
void listjishu2(int *a,unsigned int len)
{  
	if (len<2)
 	return;
  	int imax=max(a,len);   
    int t[imax+1];        
    memset(t,0,sizeof(t)); 
	int i,j,k;   
	for (i=0;i<len;i++) 
	t[a[i]]++; 
	i=0; 
	for (j=0;j<imax+1;j++)
		{   
			for (k=0;k<t[j];k++) 
			a[i++]=j; 
		}
}

//��������

int max1(int *a,unsigned int len)
{  
int i,max; 
 max=a[0]; 
  for (i=1;i<len;i++)  
    if (a[i]>max)
	 max=a[i]; 
	  return max;
}

void listjishu1(int *a,unsigned int len,unsigned int e)
{  
	int i; 
	int r[len];      
	int b[10]={0};   

	for (i=0;i<len;i++)   
	b[(a[i]/e)%10]++; 
	for (i=1;i<10;i++) 
	   b[i]=b[i]+b[i-1];  
	for (i=len-1;i>=0;i--)
	{  
	    int p=(a[i]/e)%10;  
		r[b[p]-1]=a[i];   
		b[p]--; 
	 }    
		memcpy(a,r,len*sizeof(int));
}

void listjishu(int *a,unsigned int len)
{ 
 int max=max1(a,len);   
  int p;    
 
    for (p=1;max/p>0;p=p*10) 
	 {   
	     listjishu1(a,len,p);  
	     int y;
	     printf("p=%-5d  ",p);
		 for (y=0;y<len;y++)
		  printf("%2d ",a[y]); 
		  printf("\n"); 
	}
} 
//������
void listdui(int *a,int s,int e) 
{  
   int d=s;  
   int o=d*2+1;  
   while (o<=e)  
    {     
	    if ((o+1<=e) && (a[o]<a[o+1])) 
	    o++;    
	    if (a[d]>a[o]) 
		return;    
		swap(&a[d],&a[o]);  
		d=o;   
		o=d*2+1; 
	}
}
void listdui1(int *a, int len)
 { 
  int i;  
  for (i=(len-1)/2;i>=0;i--) 
  listdui(a,i,len-1);  
    for (i=len-1;i>0;i--)  
	 {  
	     swap(&a[0],&a[i]);  
	     listdui(a,0,i-1);
	}
 } 

void listtong1(int *a,unsigned int len)
{  
	if (len<2) 
	return; 
  	int i;   
  	int j;     
   	int t;   
    
	  for (i=len-1;i>0;i--)  
	   {  
		    for (j=0;j<i;j++)  
			{      
				if (a[j]>a[j+1])   
					{    
						t=a[j+1];     
						a[j+1]=a[j];     
						a[j]=t;   
					} 
			} 
		}
}
void listtong(int *a,unsigned int len)
{ 
 	int b[5][5];    
 	int s[5]; 
   	memset(b,0,sizeof(b)); 
	memset(s,0,sizeof(s));  
	int i=0; 
	for (i=0;i<len;i++) 
	{    
	b[a[i]/10][s[a[i]/10]++]=a[i];
	}   
	for (i=0;i<5;i++) 
	{   
		listtong1(b[i],s[i]);
	}  
	int j=0,k=0; 
	for (i=0;i<5;i++) 
	{    
	for (j=0;j<s[i];j++)  
	a[k++]=b[i][j];
	}
}
void mume()
{
	printf("1.ð������\n");
	printf("2.��������\n");
	printf("3.��������\n");
	printf("4.ϣ������\n");
	printf("5.ѡ������\n");
	printf("6.��������\n");
	printf("7.��������\n");
	printf("8.������\n");
	printf("9.Ͱ����\n");
	printf("10.�˳�\n");
}

  
