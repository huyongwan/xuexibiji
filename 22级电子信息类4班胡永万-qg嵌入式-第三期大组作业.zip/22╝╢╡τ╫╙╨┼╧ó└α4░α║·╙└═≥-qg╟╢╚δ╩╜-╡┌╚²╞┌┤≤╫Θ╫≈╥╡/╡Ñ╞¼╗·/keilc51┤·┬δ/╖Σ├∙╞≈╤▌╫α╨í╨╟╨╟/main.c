#include <REGX52.H>
#include "Delay.h"
#include "Timer0.h"

sbit Buzzer=P2^5;

unsigned int FreqTable[]={63628,63731,63835,63928,64021,64103,64185,64260,64331,64400,64463,64524,
	64580,64633,64684,64732,64777,64820,64860,64898,64934,64968,65000,65030,

65058,65085,65110,65134,65157,65178,65198,65217,65235,65252,65268};

unsigned char FreqSelect,i=0;

unsigned int Music[]={12,
	12,
	19,
	19,
	21,
	21,
	19,
	17,
	17,
	16,
	16,
	14,
	14,
	12,

};


void main()
{
	Timer0_Init();
	while(1)
	{
		FreqSelect=Music[i];
		i++;
		Delay(125*Music[i]);
		i++;
		TR0=0;
		Delay(10);
		TR0=1;
	}
}

void Timer0_Routine() interrupt 1
{
	
	TL0 = FreqTable[FreqSelect]%256;//设置每一回溢出后的定时初值（具体什么初值要依据具体情况计算来的）
	TH0 = FreqTable[FreqSelect]/256;//设置每一回溢出后的定时初值（具体什么初值要依据具体情况计算来的）
	Buzzer=!Buzzer;
}