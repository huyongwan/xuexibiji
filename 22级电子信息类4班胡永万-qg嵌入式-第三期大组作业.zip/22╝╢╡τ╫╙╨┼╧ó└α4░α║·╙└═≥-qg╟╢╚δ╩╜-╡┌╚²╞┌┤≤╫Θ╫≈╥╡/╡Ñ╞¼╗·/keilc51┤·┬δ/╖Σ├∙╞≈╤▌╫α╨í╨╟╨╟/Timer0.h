#ifndef___TIMER0_H__
#define___TIMER0_H__

void Timer0_Init();
#endif