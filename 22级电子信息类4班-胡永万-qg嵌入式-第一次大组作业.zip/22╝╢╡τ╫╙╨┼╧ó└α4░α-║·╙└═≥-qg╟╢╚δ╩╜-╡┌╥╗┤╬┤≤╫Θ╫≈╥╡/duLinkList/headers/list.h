#include<stdio.h>
#include<stdlib.h>
#include<assert.h>


typedef int SU;


typedef struct list
{
	SU data;
	struct list*next;
	struct list*prev;
	
}SL;
SL* listInit(SL*px);
void listinsert(SL*pos,SU X);
void listprint(SL*px); 
void listpush(SL*px,SU X);
void popback(SL*px);
void listdestory(SL**px);
SL*listfind(SL*px,SU X);
SL*listmalloc(SU X);
void listearse(SL*pos);
void listmenu(); 
