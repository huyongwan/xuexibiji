#include<stdio.h>



typedef int SU;

typedef struct LNode
{
	
	SU data;
	struct Node*next;
	
}LN;


void listprint(LN*P);
void listPush(LN**p,SU X);
void listpushfront(LN**px,SU X);
void listpoptail(LN**px); 
LN*listfind(LN*p,SU X);
void listinsert(LN**px,LN*pos,SU X);
void listInsertafter(LN*pos,SU X);
void listearse(LN**px,LN*pox);
void listbianli(LN*px);
LN*listzhaozhongdian(LN*px);
 void listpanduanchenghuan(LN*px);
 void listdestory(LN**px);
 void listfanzhuan(LN**px); 
 void listjioubianhuan(LN**px);
 void listmenu();
