#include<stdio.h>
#include<stdlib.h>
#include<assert.h>
#include<stdbool.h>

typedef int SU;

typedef struct stack{
	SU*a;
	int top;
	int size;
	
	
}SL;

void stackInit(SL*px);
void stackdestroy(SL*px);
void stackpop(SL*px);
void stackpush(SL*px,SU X);
SU stacktop(SL*px);
int stacksize(SL*px);
bool stackempty(SL*px);
void stackpopL(SL*px); 
void stackpopLone(SL*px);
void stackbianli(SL*px);
void listmenu();
