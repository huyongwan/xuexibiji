#include"list.h"


//��ʼ�� 
void stackInit(SL*px)
{
	assert(px);
	px->a=NULL;
	px->top=0;
	px->size=0;
	
}

void stackdestroy(SL*px)
{
	assert(px); 
	free(px->a);
	px->a=NULL;
	px->size=px->top=0;
	
}

void stackpush(SL*px,SU X)
{
	assert(px); 
	if(px->top==px->size)
	{
		int newword =px->size==0?4:px->size*2;
		SU*tmp=realloc(px->a,sizeof(SU)*newword);
		if(tmp==NULL)
		{
			printf("realloc fail\n");
			exit(-1);
			
		}
		px->a=tmp;
		px->size=newword;
	}
	px->a[px->top]=X;
	px->top++;
}

void stackpop(SL*px)
{
	assert(px);
	assert(px->top>0);

	px->top--;

}


SU stacktop(SL*px)
{
	assert(px);
	assert(px->top>0);
	return px->a[px->top-1];
	
	
}


int stacksize(SL*px)
{
	assert(px);
	return px->top;
	
	
}



bool stackempty(SL*px)
{
	
	assert(px);
	return px->top==0;
	
}
void stackpopL(SL*px)
{
	while(!stackempty(px))
	{
	  printf("%d  ",stacktop(px));
	  
	  stackpop(px);
	  }
}
void stackpopLone(SL*px)
{
	printf("%d  ",stacktop(px));
	  
	  stackpop(px);
}
void listmenu()
{
	printf("            ջϵͳ���ܲ˵�          \n");
	printf("1.��ʼ��ջ\n");
	printf("2.�ж�ջ�Ƿ�Ϊ��\n");
	printf("3.�õ�ջ��Ԫ��\n");
	printf("4.���ջ\n");
	printf("5.����ջ\n");
	printf("6.���ջ����\n");
	printf("7.��ջ\n");
	printf("8.ȫ����ջ\n"); 
	printf("9.������ջ\n"); 
	printf("10.����ջ\n");
	printf("11.�˳�\n");
}
void stackbianli(SL*px)
{
	int i;
for(i=0;i<px->top;i++)
{
	printf("%d  ",px->a[i]);
	
	}	
	
	
}
 
