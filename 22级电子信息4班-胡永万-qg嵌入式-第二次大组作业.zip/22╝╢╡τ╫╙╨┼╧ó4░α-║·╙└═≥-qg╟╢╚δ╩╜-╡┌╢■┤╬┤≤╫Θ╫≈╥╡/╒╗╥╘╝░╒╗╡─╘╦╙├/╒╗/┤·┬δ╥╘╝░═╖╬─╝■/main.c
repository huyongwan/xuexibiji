#include <stdio.h>
#include <stdlib.h>
#include"list.h"
/* run this program using the console pauser or add your own getch, system("pause") or input loop */



void test()
{int i;
	SL ps;
	stackInit(&ps);
	 stackpush(&ps,1);
	 stackpush(&ps,2);
	 stackpush(&ps,3);
	 
	 //printf("%d\n",stacktop(&ps));
	 
	stackpopL(&ps);
}
void test1()
{   int a;
	int num;
	SL ps; 
	listmenu();
	while(1)
	{	
		
		printf("����������ʵ�ֵĹ��ܣ�"); 
 		scanf("%d",&a);
		switch(a){
		case 1:
			stackInit(&ps);
			printf("ջ��ʼ���ɹ���\n"); 
			break; 
		case 2:	
			if(stackempty(&ps))
			{
				printf("ջΪ��!\n");
			}
			else{
				printf("ջ��Ϊ��!\n");
			}
			break;
		case 3:
		 printf("%d\n",stacktop(&ps));
		 break;
		case 4:
			stackpop(&ps);
			printf("ջ�Ѿ���գ�\n");
			break;
		case 5:
			stackdestroy(&ps);
			printf("ջ�Ѿ�����!\n");
			break;
		case 6:
			printf("ջ�ĳ���Ϊ%d\n",stacksize(&ps));
			break;
		case 7:
			printf("������������������ݣ�");
				scanf("%d",&num); 
				stackpush(&ps,num);
				break;
		case 8:
			stackpopL(&ps);
			break;
		case 9:
			stackpopLone(&ps);
			break;
		case 10:
			 stackbianli(&ps);
			 printf("\n");
			 break;
		case 11:
			return ;
	 } 

}


}
int main(int argc, char *argv[]) {
	
	test1();
	
	
	return 0;
}
