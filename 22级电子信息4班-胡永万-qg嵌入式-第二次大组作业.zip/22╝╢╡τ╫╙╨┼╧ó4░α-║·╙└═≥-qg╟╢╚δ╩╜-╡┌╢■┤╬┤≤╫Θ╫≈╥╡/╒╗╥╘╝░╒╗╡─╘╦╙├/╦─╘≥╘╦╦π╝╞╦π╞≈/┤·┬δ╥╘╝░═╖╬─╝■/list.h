#include<stdio.h>
#include<stdlib.h>
#include<assert.h>
#include<stdbool.h>

typedef int SU;
typedef char SN;
typedef struct stack{
	SU*a;
	int top;
	int size;
	
	
}SL;
typedef struct stack1{
	SN*a;
	int top;
	int size;
	
	
}CHA;


void stackInit(CHA*px);
void stackInit2(SL*px);
void stackpop(SL*px);
void stackpop2(CHA*px);
void stackpush(SL*px,SU X);
SU stacktop(SL*px);
SN stacktop2(CHA*px);
int stackpopLone1(SL*px);
char stackpopLone2(CHA*px);
void listmenu();
int stackfuhaopanduan(char ch);
int stack2(int a,char ch,int b);
void stackpush2(CHA*px,SU X);
void stackbianli(SL*px);
void stackbianli2(CHA*px);
