#include"list.h"


//��ʼ�� 
void stackInit(CHA*px)
{
	assert(px);
	px->a=NULL;
	px->top=0;
	px->size=0;
	
}
void stackInit2(SL*px)
{
	assert(px);
	px->a=NULL;
	px->top=0;
	px->size=0;
	
}

void stackpush(SL*px,SU X)
{
	int newword;
	if(px->top==px->size)
	{
		newword =px->size==0?4:px->size*2;
		SU*tmp=realloc(px->a,sizeof(SU)*newword);
		if(tmp==NULL)
		{
			printf("realloc fail\n");
			exit(-1);
			
		}
		px->a=tmp;
		px->size=newword;
	}
	px->a[px->top]=X;
	px->top++;

}
void stackpush2(CHA*px,SU X)
{
	//printf("9\n"); 
	int newword;
	if(px->top==px->size)
	{
		newword =px->size==0?4:px->size*2;
		SN*tmp=realloc(px->a,sizeof(SN)*newword);
		if(tmp==NULL)
		{
			printf("realloc fail\n");
			exit(-1);
			
		}
		px->a=tmp;
		px->size=newword;
	}
	px->a[px->top]=X;
	px->top++;

}

void stackpop(SL*px)
{
	assert(px);
	assert(px->top>0);
	px->top--;

}
void stackpop2(CHA*px)
{
	assert(px);
	assert(px->top>0);
	
	px->top--;

}
SU stacktop(SL*px)
{
	assert(px);
	assert(px->top>0);
	return px->a[px->top-1];
	
	
}

SN stacktop2(CHA*px)
{
	assert(px);
	assert(px->top>0);
	return px->a[px->top-1];
	
	
}
int stackpopLone1(SL*px)
{
	int y=stacktop(px);
	  
	  stackpop(px);
	  return y;
	  
}
char stackpopLone2(CHA*px)
{
	char y=stacktop2(px);
	  
	  stackpop2(px);
	  return y;
	  
}
void listmenu()
{
	printf("            ջϵͳ���ܲ˵�          \n");
	printf("1.��ʼ��ջ\n");
	printf("2.�ж�ջ�Ƿ�Ϊ��\n");
	printf("3.�õ�ջ��Ԫ��\n");
	printf("4.���ջ\n");
	printf("5.����ջ\n");
	printf("6.���ջ����\n");
	printf("7.��ջ\n");
	printf("8.ȫ����ջ\n"); 
	printf("9.������ջ\n"); 
	printf("10.����ջ\n");
	printf("11.�˳�\n");
}

int stackfuhaopanduan(char ch)
{
	if(ch=='+'||ch=='-')
	{
		return 1;
	}
	
	if(ch=='*'||ch=='/')
	{
		return 2;
	}
	if(ch=='(')
	{
		return 3;
	}
	if(ch==')')
	{
		return 0;
	}
}
 int stack2(int a,char ch,int b)
 {
 	switch(ch)
 	{
 		case '+':
 			return a+b;
 		case '-':
 			return a-b;
 		case '*':
 			return a*b;
 		case '/':
 			return a/b;
 			
	 }
 	
 	
 	
 }
void stackbianli(SL*px)
{
	int i;
	for(i=0;i<px->top;i++)
	{
		printf("%d  ",px->a[i]);
		
	}	
		
	printf("\n");	
	}
void stackbianli2(CHA*px)
{
	int i;
	for(i=0;i<px->top;i++)
	{
		printf("%c  ",px->a[i]);
		
	}	
		
	printf("\n");	
}
