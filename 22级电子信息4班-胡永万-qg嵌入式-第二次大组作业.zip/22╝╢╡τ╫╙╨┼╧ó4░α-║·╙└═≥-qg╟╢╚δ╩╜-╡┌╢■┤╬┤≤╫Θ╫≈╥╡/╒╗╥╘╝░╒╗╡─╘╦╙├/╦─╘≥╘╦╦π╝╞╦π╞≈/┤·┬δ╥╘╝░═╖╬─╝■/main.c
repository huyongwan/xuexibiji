#include <stdio.h>
#include <stdlib.h>
#include"list.h"
/* run this program using the console pauser or add your own getch, system("pause") or input loop */



/*void test()
{int i;
	SL ps;
	stackInit(&ps);
	 stackpush(&ps,1);
	 stackpush(&ps,2);
	 stackpush(&ps,3);
	 
	 //printf("%d\n",stacktop(&ps));
	 
	stackpopL(&ps);
}
void test1()
{   int a;
	int num;
	SL ps; 
	listmenu();
	while(1)
	{	
		
		printf("����������ʵ�ֵĹ��ܣ�"); 
 		scanf("%d",&a);
		switch(a){
		case 1:
			stackInit(&ps);
			printf("ջ��ʼ���ɹ���\n"); 
			break; 
		case 2:	
			if(stackempty(&ps))
			{
				printf("ջΪ��!\n");
			}
			else{
				printf("ջ��Ϊ��!\n");
			}
			break;
		case 3:
		 printf("%d\n",stacktop(&ps));
		 break;
		case 4:
			stackpop(&ps);
			printf("ջ�Ѿ���գ�\n");
			break;
		case 5:
			stackdestroy(&ps);
			printf("ջ�Ѿ�����!\n");
			break;
		case 6:
			printf("ջ�ĳ���Ϊ%d\n",stacksize(&ps));
			break;
		case 7:
			printf("������������������ݣ�");
				scanf("%d",&num); 
				stackpush(&ps,num);
				break;
		case 8:
			stackpopL(&ps);
			break;
		case 9:
			stackpopLone(&ps);
			break;
		case 10:
			 stackbianli(&ps);
			 printf("\n");
			 break;
		case 11:
			return ;
	 } 

}*/
void test()
{	

	int h;
	int n; 
	char a[2000];
	int i;
	printf("                                                      �������������            \n"); 
	printf("                                            **ע�⣺ֻ֧��0~9֮��ļӼ��˳���**\n"); 
			printf("                                ϵͳ�����Զ������������ڴ����߼������������......\n"); 
	printf("        �������������������ʽ�ӣ�"); 
		
	scanf("%s",&a);
	SL p;
	CHA q;
	int an;
	stackInit2(&p);
	stackInit(&q);
int s;
for(i=0;a[i];i++)
{

		if(a[i]>='0'&&a[i]<='9')
		{
			stackpush(&p,a[i]-'0');
			//stackbianli(&p);
		}
		
		else{
		//printf("\n1\n");
			if(q.top==0)
			{
				//printf("11\n");
				stackpush2(&q,a[i]);
				//stackbianli2(&q);
				
			}
			else
			{
				 n=stackfuhaopanduan(q.a[q.top-1]);	
				 h=stackfuhaopanduan(a[i]);	
				if(n>h&&a[i]!=')'&&q.a[q.top-1]!='(')	{
			
				//printf("1\n");
					char y=stackpopLone2(&q);
					int j=stackpopLone1(&p);
					int k=stackpopLone1(&p);
						//printf("9\n");
				
					//stackbianli2(&q);
					//printf ("%d\n",stack2(k,y,j));
					stackpush(&p,stack2(k,y,j));
				
			//	printf("6\n");
				stackpush2(&q,a[i]);
			//	printf("6\n");
			//	stackbianli2(&q);
				}
				if(n>h&&a[i]==')')
				{
					while(q.a[q.top-1]!='(')
					{
					
					char t=stackpopLone2(&q);
					int w=stackpopLone1(&p);
					int l=stackpopLone1(&p);
					stackpush(&p,stack2(l,t,w));
					}
					stackpop2(&q); 
				}
				if(n<h||q.a[q.top-1]=='(')
				{
				//	printf("%c23\n",q.a[q.top-1]);
					stackpush2(&q,a[i]);
				//	printf("wn\n");
					//printf("%c23\n",q.a[q.top-1]);
					//	stackbianli2(&q);
					//	printf("1\n");
						
				}
				if(n==h){
					an=1;
					while(an==1){
					
					char en=stackpopLone2(&q);
					int r=stackpopLone1(&p);
					int z=stackpopLone1(&p);
					
					stackpush(&p,stack2(z,en,r));
					 n=stackfuhaopanduan(q.a[q.top-1]);	
				 h=stackfuhaopanduan(a[i]);	
						if(n!=h){
							stackpush2(&q,a[i]);
							an=0;
						}
					}
				}
			}
		}
		
}
//printf("%d\n",q.top);
//stackbianli2(&q);
//	stackbianli(&p);
int nb=q.top-1;
int tw=q.top;
	for(s=0;s<tw;s++)
	{
	
	if(tw>1){
		//printf("4\n");
		
		char v=stackpopLone2(&q);
					int u=stackpopLone1(&p);
					int o=stackpopLone1(&p);
				//	printf("%d\n",q.top);
					//printf("%d\n",u);
					//printf("%d\n",o);
					//printf("%c\n",v);
//stackbianli2(&q);
//	stackbianli(&p);
		if(s!=nb)
		{
			stackpush(&p,stack2(o,v,u));
			//stackbianli(&p);
			//printf("3\n");
			//stackbianli(&p);
		}else if(s==1){
		//printf("07\n");	
			printf("      ʽ������Ľ��Ϊ��%d",stack2(o,v,u));
				//printf("03\n");			
		}
					
	}else{
			char d=stackpopLone2(&q);
			int b=stackpopLone1(&p);
			int x=stackpopLone1(&p);
			printf("     ʽ������Ľ��Ϊ��%d\n",stack2(x,d,b));
				}
	
		
	//	printf("6\n");
}
}


int main(int argc, char *argv[]) {
	
	test();
	
	
	return 0;
}
