#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
#include<assert.h>
int n;



typedef int SU;

typedef struct queue{
	
	struct queue*next;
	void*data;
	
}SL;
typedef struct queue2{
	
	SL*head;
	SL*tail;
	
}QL;

void queueInit(QL*px);
void queuedestroy(QL*px);
void queuePush(QL*px,void*data1);
void queuePop(QL*px);
void queueFront(QL*px);
void queueBack(QL*px);
int queueSize(QL*px);
bool queueEmpty(QL*px);
void queuechu(QL*px);
void get_int(void**data1);
void get_float(void**data1);
void get_char(void**data1);
void dayin(void*data);
void queuechu1(QL*px;); 
