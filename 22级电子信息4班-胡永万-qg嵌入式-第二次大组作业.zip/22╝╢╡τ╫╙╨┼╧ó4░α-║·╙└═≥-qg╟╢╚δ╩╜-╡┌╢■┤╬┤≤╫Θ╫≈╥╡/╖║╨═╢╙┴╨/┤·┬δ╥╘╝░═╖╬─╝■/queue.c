#include "queue.h"

//��ʼ�� 
void queueInit(QL*px)
{
	assert(px);
	px->head=NULL;
	px->tail=NULL;
}
void queuedestroy(QL*px)
{
	assert(px);
	SL*cur=px->head;
	while(cur!=NULL)
	{
		SL*next=cur->next;
		free(cur);
		cur=next;
		
	}
	px->head=px->tail=NULL;
	
}
void queuePush(QL*px,void*data1)
{
	assert(px);
	//printf ("1\n");
	SL*newword=(SL*)malloc(sizeof(SL));
	newword->data=data1;
	newword->next=NULL;
	if(px->head==NULL)
	{
		px->head=px->tail=newword; 
	}else
	{
		px->tail->next=newword;
		px->tail=newword;
		
		
	}
	
	
	
	
}
void queuePop(QL*px)
{
	assert(px);
	assert(!queueEmpty(px));
	SL*next=px->head->next;
	free(px->head);
	px->head=next;
	if(px->head==NULL)
	{
		px->tail=NULL;
		
	}
	
	
}
void queueFront(QL*px)
{
	assert(px);
	assert(!queueEmpty(px));
	
	dayin(px->head->data);
	//printf("\n"); 
	
}
void dayin(void*data)
{
	switch(n)
	{
		case 1:
			printf("%d",*(int*)data);
			break;
		case 2:
			printf("%lf",*(float*)data);	
			break;
		case 3:
			printf("%c",*(char*)data);
			break;
		
	}
	
}
void queueBack(QL*px)
{
		assert(px);
	assert(!queueEmpty(px));
	dayin(px->tail->data);
	printf("\n"); 
}
int queueSize(QL*px)
{
	assert(px);
	int n=0;
	SL*cur =px->head; 
	while(cur){
		++n;
		cur=cur->next;
		
	}
	
	return n;
}


bool queueEmpty(QL*px)
{
	assert(px);
	return px->head==NULL;
	
}
void queuechu(QL*px)
{
	while(!queueEmpty(px))
	{
	
		switch(n)
	{
		case 1:
			queueFront(px);
			queuePop(px);
			break;
		case 2:
			queueFront(px);
			queuePop(px);
			break;
		case 3:
			queueFront(px);
			queuePop(px);
			break;
		
	}
}
	 
	 printf("\n");
	
}

void queuechu1(QL*px)
{
		switch(n)
	{
		case 1:
			queueFront(px);
			queuePop(px);
			break;
		case 2:
			queueFront(px);
			queuePop(px);
			break;
		case 3:
			queueFront(px);
			queuePop(px);
			break;
		
	}

	 
	 printf("\n");
	
}


void get_int(void**data1)
{
	printf("������������֣�");

	*data1=(int*)malloc(sizeof(int));
	 	scanf("%d",*data1);
	
}
void get_float(void**data1)
{
	printf("��������ĸ�������");

	float*h=(float*)malloc(sizeof(float));
	*data1=h;
	 	scanf("%f",*data1);
	
}
void get_char(void**data1)
{
	printf("����������ַ���");
	*data1=(char*)malloc(sizeof(char));
	scanf("%c",*data1);
	while (getchar()!='\n');
	//printf ("111");
	
	//printf ("112");
	
	
}

